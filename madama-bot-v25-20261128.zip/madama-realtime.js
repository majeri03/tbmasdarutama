// Madama Agent — REALTIME, untuk jalan di server Oracle Cloud (Always Free)
// Cara kerja:
//  - Bot jalan terus (PM2), dengerin WhatsApp langsung lewat Baileys.
//    Bukan dicek tiap 2 menit. Ada pesan yang manggil -> dibalas dalam hitungan detik.
//  - Hanya balas kalau dipanggil "Madama Agent" (bebas huruf besar/kecil, bebas spasi).
//  - JANGAN PERNAH sebut nama "Jery" di balasan grup. Jawab langsung tanpa nama.
//  - Otak bot = file data di folder ini (harga.json, pengetahuan.json, orders.json).
//    File-file itu yang dirawat Jett. Bot baca ulang file itu SETIAP ada pesan masuk,
//    jadi kalau Jett update daftar harga / jawaban, bot langsung pakai yang baru
//    tanpa restart. Inilah cara Jett "tetap aktif" di grup: lewat data yang dia ajarkan.
//  - Kalau ada pertanyaan yang bot belum tahu jawabannya, bot catat ke
//    unanswered.json, jawab "saya catat dulu", dan Jett yang isi jawabannya nanti.
//
// Jalankan di Oracle:
//   node madama-realtime.js --phone 6288804230743
//   -> masukkan kode pairing di HP: WhatsApp > Perangkat tertaut > Tautkan perangkat
//      > Tautkan dengan nomor telepon
//   Produksi (auto-restart): pm2 start ecosystem.config.js
//     atau: pm2 start madama-realtime.js --name madama -- --phone 6288804230743
//
// OTAK BOT — JUJUR:
//   Aku (Jett / Muse) TIDAK punya API resmi yang bisa dipanggil bot ini secara
//   langsung. Muse itu agen pribadi, tidak ada API publik untuk chat agennya.
//   Jadi ada 2 lapis otak:
//   1) Aturan + file data (harga.json, pengetahuan.json, orders.json) — ini yang
//      Jett rawat. Harga, rangkuman orderan, sejarah toko dijawab dari sini,
//      deterministik, tidak boleh mengarang.
//   2) OPSIONAL: Gemini API gratis (GEMINI_API_KEY) untuk pertanyaan bebas.
//      Bot kirim pertanyaan + isi file data ke Gemini, Gemini jawab dalam
//      hitungan detik. Ini BUKAN Jett, tapi cara jawabnya dibuat meniru Jett:
//      prompt-nya ditulis Jett, datanya dari Jett, aturannya dari Jett.
//   3) OPSIONAL, PALING BERISIKO: muse2api (MUSE2API_URL + MUSE2API_KEY).
//      Jembatan TIDAK RESMI ke muse.ai, jalan di localhost Oracle yang sama
//      (http://127.0.0.1:18610/v1/chat/completions). Kalau env ini diisi, bot
//      coba tanya ke Jett lewat jembatan itu DULU untuk pertanyaan bebas.
//      Kalau jembatan mati / lambat / gagal, bot kembali ke Gemini / aturan.
//      JANGAN isi env ini kalau gateway tidak jalan di localhost yang sama.
//      JANGAN pernah kirim cookie Muse lewat chat. Lihat muse2api-safe/README-AMAN.md.
const fs = require('fs')
const path = require('path')
const pino = require('pino')
const {
  default: makeWASocket,
  useMultiFileAuthState,
  fetchLatestBaileysVersion,
  DisconnectReason
} = require('@whiskeysockets/baileys')

const DATA_DIR = __dirname
// Config testing / produksi + whitelist nomor. Dibaca dari config.json + roles.json.
// Kalau file tidak ada, fallback aman: hanya grup Orderan, semua orang baca saja.
const DEFAULT_CONFIG = {
  mode: 'testing',
  testGroupName: 'Madama Test',
  productionGroupName: 'Orderan',
  allowedGroups: [{ name: 'Madama Test', jid: '', enabled: true }],
  context: { maxHistoryTurns: 2, historyTtlMinutes: 30, maxPromptChars: 4000, maxReplyChars: 600, aiCooldownSeconds: 10, maxAiCallsPerHourPerSender: 20 },
  web: { enabled: false, baseUrl: 'https://tbmasdarutama.vercel.app', allowlistGet: ['/api/bot/products', '/api/bot/stock', '/api/bot/customers'], allowWrites: false, requireConfirmation: true, timeoutMs: 10000 }
}
function loadConfig() {
  const c = loadJson('config.json', DEFAULT_CONFIG)
  return { ...DEFAULT_CONFIG, ...c, context: { ...DEFAULT_CONFIG.context, ...(c.context || {}) }, web: { ...DEFAULT_CONFIG.web, ...(c.web || {}) } }
}
function loadRoles() {
  return loadJson('roles.json', { level1_full_access: [], level2_medium_create_transaction: [] })
}
function digitsOnly(s) { return (s || '').replace(/\D/g, '') }
function senderNumber(m) {
  // Grup: m.key.participant. DM: m.key.remoteJid. Bersihkan suffix :5@s.whatsapp.net
  // WhatsApp baru sering kirim participant sebagai LID (2157...@lid), bukan nomor HP.
  // Kalau ada participantAlt (nomor HP asli @s.whatsapp.net), pakai itu dulu.
  const candidates = [m.key.participantAlt, m.key.participant, m.key.remoteJidAlt, m.key.remoteJid].filter(Boolean)
  for (const raw of candidates) {
    const s = String(raw)
    if (s.includes('@s.whatsapp.net')) {
      const num = digitsOnly(s.split(':')[0].split('@')[0])
      if (num) return num
    }
  }
  const raw = candidates[0] || ''
  return digitsOnly(String(raw).split(':')[0].split('@')[0])
}
function senderLid(m) {
  const raw = m.key.participant || ''
  if (String(raw).includes('@lid')) return digitsOnly(String(raw).split(':')[0].split('@')[0])
  return ''
}
function senderLevel(m, lidPhoneMap) {
  const roles = loadRoles()
  const n = senderNumber(m)
  const lid = senderLid(m)
  // Kalau pengirim hanya LID, coba petakan LID -> nomor HP dari info grup
  // (groupMetadata participants punya phoneNumber). Jadi tidak perlu
  // daftarkan LID manual — nomor HP di roles.json sudah cukup.
  const mappedPhone = (lid && lidPhoneMap && lidPhoneMap[lid]) ? digitsOnly(lidPhoneMap[lid]) : ''
  const ids = [n, lid, mappedPhone].filter(Boolean)
  const l1 = (roles.level1_full_access || []).map(digitsOnly)
  const l2 = (roles.level2_medium_create_transaction || []).map(digitsOnly)
  if (ids.some(id => l1.includes(id))) return 1
  if (ids.some(id => l2.includes(id))) return 2
  return 3
}
// LID OTOMATIS MASUK LEVEL 1/2 (v2.5):
// Level 1 tidak terbatas satu nomor. Kalau LID pengirim terpetakan ke nomor HP
// lewat groupMetadata (participantAlt / phoneNumber) DAN nomor HP itu SUDAH
// terdaftar di Level 1 (atau Level 2), LID itu otomatis ditambahkan ke daftar
// level yang sama di roles.json dan disimpan ke disk — jadi lain kali bot kenal
// LID itu langsung tanpa perlu pemetaan grup.
// ATURAN KERAS:
//  - LID yang TIDAK terpetakan ke nomor terdaftar TIDAK PERNAH ditambahkan.
//  - TIDAK PERNAH naik level: LID dari nomor Level 3 (baca saja) tidak
//    ditambahkan ke mana pun. Level 3 tetap hanya-baca.
//  - Tidak ada duplikat: cek dulu sebelum tambah; kalau sudah ada, tidak
//    ditulis ulang.
//  - Kalau roles.json gagal disimpan, tulis error ke log, JANGAN crash bot.
function maybeAutoAddLid(m, lidMap) {
  try {
    const lid = senderLid(m)
    if (!lid) return
    const mapped = lidMap && lidMap[lid] ? digitsOnly(lidMap[lid]) : ''
    if (!mapped) return // tidak terpetakan -> jangan tambah apa pun
    const roles = loadRoles()
    const l1 = (roles.level1_full_access || []).map(digitsOnly)
    const l2 = (roles.level2_medium_create_transaction || []).map(digitsOnly)
    let changed = false
    if (l1.includes(mapped) && !l1.includes(lid)) {
      roles.level1_full_access = roles.level1_full_access || []
      roles.level1_full_access.push(lid)
      changed = true
      console.log('[LEVEL] LID ' + lid + ' otomatis ditambah ke Level 1 (nomor ' + mapped + ')')
    } else if (l2.includes(mapped) && !l2.includes(lid)) {
      roles.level2_medium_create_transaction = roles.level2_medium_create_transaction || []
      roles.level2_medium_create_transaction.push(lid)
      changed = true
      console.log('[LEVEL] LID ' + lid + ' otomatis ditambah ke Level 2 (nomor ' + mapped + ')')
    }
    if (changed) {
      try {
        saveJson('roles.json', roles)
      } catch (e) {
        console.log('[LEVEL] Gagal simpan roles.json:', e.message)
      }
    }
  } catch (e) {
    console.log('[LEVEL] Gagal cek LID otomatis:', e.message)
  }
}
// Dari participants groupMetadata, buat peta LID -> nomor HP.
// Baileys: participant.id bisa LID, participant.phoneNumber nomor HP-nya.
function lidPhoneMapFromParticipants(participants) {
  const map = {}
  for (const p of participants || []) {
    const id = p && (p.id || p.jid || '')
    const phone = p && (p.phoneNumber || p.phone || '')
    if (id && phone) {
      const lid = digitsOnly(String(id).split(':')[0].split('@')[0])
      if (lid) map[lid] = String(phone)
    }
  }
  return map
}
function isGroupAllowed(subject, remoteJid) {
  const cfg = loadConfig()
  const groups = cfg.allowedGroups || []
  // Cocokkan JID dulu kalau diisi, kalau tidak cocokkan nama (case-insensitive)
  const hit = groups.find(g => g.enabled !== false && (
    (g.jid && g.jid === remoteJid) ||
    (!g.jid && subject && g.name && subject.toLowerCase() === g.name.toLowerCase())
  ))
  if (hit) return true
  // Fallback lama: kalau config kosong, izinkan sesuai mode
  if (!groups.length) {
    const want = cfg.mode === 'production' ? cfg.productionGroupName : cfg.testGroupName
    return subject && subject.toLowerCase() === want.toLowerCase()
  }
  return false
}
const SEEN_FILE = path.join(DATA_DIR, 'seen.json')
const GEMINI_API_KEY = process.env.GEMINI_API_KEY || ''
const GEMINI_MODEL = process.env.GEMINI_MODEL || 'gemini-2.5-flash'
const MUSE2API_URL = process.env.MUSE2API_URL || ''
const MUSE2API_KEY = process.env.MUSE2API_KEY || ''

const args = process.argv.slice(2)
let phone = process.env.WA_PHONE || ''
for (let i = 0; i < args.length; i++) {
  if (args[i] === '--phone' && args[i + 1]) phone = args[i + 1].replace(/\D/g, '')
}
if (phone) phone = phone.replace(/\D/g, '')

// ---------- helpers ----------
function loadJson(name, fallback) {
  try {
    const p = path.join(DATA_DIR, name)
    if (!fs.existsSync(p)) return fallback
    return JSON.parse(fs.readFileSync(p, 'utf8'))
  } catch (e) {
    console.log('Gagal baca ' + name + ':', e.message)
    return fallback
  }
}
function saveJson(name, data) {
  fs.writeFileSync(path.join(DATA_DIR, name), JSON.stringify(data, null, 2))
}
function todayWita() {
  // YYYY-MM-DD di Asia/Makassar (WITA, UTC+8)
  return new Date().toLocaleDateString('en-CA', { timeZone: 'Asia/Makassar' })
}
function nowWita() {
  return new Date().toLocaleString('id-ID', { timeZone: 'Asia/Makassar' })
}
function normalize(text) {
  return (text || '').toLowerCase().replace(/[^a-z0-9]/g, '')
}
function isCalled(text, m, botPhone, botLid) {
  if (normalize(text).includes('madamaagent')) return true
  const ctx = m && (m.message?.extendedTextMessage?.contextInfo || m.message?.imageMessage?.contextInfo || null)
  // Balas pesan bot (reply / quote ke pesan bot) = dipanggil, tanpa perlu ketik nama lagi.
  if (ctx && ctx.quotedMessage && ctx.participant) {
    const q = digitsOnly(String(ctx.participant).split(':')[0].split('@')[0])
    if ((botPhone && q === botPhone) || (botLid && q === botLid)) return true
  }
  // Panggil lewat tag @bot: WhatsApp sering pakai LID bot (@2157...), bukan nomor HP.
  // Jadi cek mentionedJid terhadap nomor HP DAN LID bot.
  const botIds = [botPhone, botLid].filter(Boolean)
  if (botIds.length) {
    for (const id of botIds) {
      if ((text || '').includes('@' + id)) return true
    }
    const mentioned = (ctx && ctx.mentionedJid) || []
    for (const jid of mentioned) {
      if (botIds.includes(digitsOnly(String(jid).split(':')[0].split('@')[0]))) return true
    }
  }
  return false
}
function botLidFromParticipants(participants, botPhone) {
  for (const p of participants || []) {
    const phone = p && (p.phoneNumber || p.phone || '')
    if (botPhone && phone && digitsOnly(String(phone)) === botPhone) {
      const id = p.id || p.jid || ''
      return digitsOnly(String(id).split(':')[0].split('@')[0])
    }
  }
  return ''
}
function stripTrigger(text, botPhone, botLid) {
  // Buang kata "madama agent" (berbagai bentuk) dan tag @bot (nomor / LID), sisakan isinya
  botPhone = botPhone || phone || ''
  let t = (text || '').replace(/madama\s*agent/gi, '').trim()
  for (const id of [botPhone, botLid].filter(Boolean)) {
    t = t.replace(new RegExp('@' + id, 'g'), '').trim()
  }
  // Tag WhatsApp tampil sebagai @angka panjang, buang @angka di awal pesan juga
  t = t.replace(/^@\d+\s*/, '').trim()
  return t
}

let seen = new Set(loadJson('seen.json', []))
function markSeen(id) {
  seen.add(id)
  if (seen.size > 500) seen = new Set([...seen].slice(-300))
  saveJson('seen.json', [...seen])
}

// ---------- optimasi: cache file, cache grup, riwayat pendek, rate limit ----------
// Harga / pengetahuan dibaca ulang hanya kalau file berubah (mtime), bukan tiap pesan.
const fileCache = {}
function loadCached(name, fallback) {
  try {
    const p = path.join(DATA_DIR, name)
    if (!fs.existsSync(p)) return fallback
    const mtime = fs.statSync(p).mtimeMs
    if (fileCache[name] && fileCache[name].mtime === mtime) return fileCache[name].data
    const data = JSON.parse(fs.readFileSync(p, 'utf8'))
    fileCache[name] = { mtime, data }
    return data
  } catch (e) { return fallback }
}
// Cache metadata grup 1 jam, supaya tidak panggil groupMetadata tiap pesan.
const groupCache = new Map()
function getCachedGroup(remoteJid) { const e = groupCache.get(remoteJid); return e && Date.now() - e.ts < 3600000 ? e.subject : null }
function getCachedLidMap(remoteJid) { const e = groupCache.get(remoteJid); return e && Date.now() - e.ts < 3600000 ? (e.lidMap || {}) : {} }
function setCachedGroup(remoteJid, subject, lidMap) { groupCache.set(remoteJid, { subject, lidMap: lidMap || {}, ts: Date.now() }) }
// Riwayat pendek per grup: maks 2 giliran, 30 menit, tiap giliran dipotong 200 karakter.
// AI hanya baca ini, bukan seluruh chat grup.
const history = new Map()
function getHistory(remoteJid) {
  const cfg = loadConfig()
  const list = history.get(remoteJid) || []
  const fresh = list.filter(h => Date.now() - h.ts < (cfg.context.historyTtlMinutes || 30) * 60000)
  return fresh.slice(-(cfg.context.maxHistoryTurns || 2))
}
function addHistory(remoteJid, q, a) {
  const list = getHistory(remoteJid)
  list.push({ q: (q || '').slice(0, 200), a: (a || '').slice(0, 200), ts: Date.now() })
  history.set(remoteJid, list)
}
// Rate limit AI: 1 panggilan per 10 detik per grup, maks 20/jam per pengirim.
const aiCalls = new Map()
function aiAllowed(remoteJid, sender) {
  const cfg = loadConfig()
  const now = Date.now()
  const key = remoteJid + '|' + sender
  const list = (aiCalls.get(key) || []).filter(t => now - t < 3600000)
  const last = list[list.length - 1]
  if (last && now - last < (cfg.context.aiCooldownSeconds || 10) * 1000) return false
  if (list.length >= (cfg.context.maxAiCallsPerHourPerSender || 20)) return false
  list.push(now); aiCalls.set(key, list); return true
}
function auditLog(entry) {
  try { fs.appendFileSync(path.join(DATA_DIR, 'audit.jsonl'), JSON.stringify({ waktu: nowWita(), ...entry }) + '\n') } catch (e) {}
}
// Web API aman: default MATI. Kalau diaktifkan, hanya GET ke allowlist
// /api/bot/*, HTTPS saja, timeout 10 detik.
// Setiap panggilan kirim 3 header:
//   X-Bot-Key    : kunci API bot dari env WA_BOT_API_KEY (di VM + Vercel,
//                  jangan di chat). Bila belum diisi, fallback SATU RILIS
//                  ke TB_API_KEY lama + log peringatan, supaya VM yang
//                  sekarang tidak langsung rusak.
//   X-Bot-Level  : 1/2/3, level pengirim pesan yang memicu panggilan.
//   X-Bot-Sender : nomor HP pengirim bila terpetakan, kalau tidak LID-nya.
// webGet(pathname, level, sender) — level & sender diisi pemanggil.
// CATATAN: di v2.5 webGet masih belum dipanggil answer() (web default OFF);
// header ini aktif begitu WS-B / wiring berikutnya memanggil webGet.
let warnedBotKeyFallback = false
async function webGet(pathname, level, sender) {
  const cfg = loadConfig()
  if (!cfg.web.enabled) return null
  if (!cfg.web.allowlistGet.some(p => pathname === p || pathname.startsWith(p + '/'))) return null
  let key = process.env.WA_BOT_API_KEY || ''
  if (!key && process.env.TB_API_KEY) {
    key = process.env.TB_API_KEY
    if (!warnedBotKeyFallback) {
      warnedBotKeyFallback = true
      console.log('[WEB] WA_BOT_API_KEY belum diisi, memakai TB_API_KEY — segera ganti ke WA_BOT_API_KEY')
    }
  }
  if (!key) return null
  const base = (cfg.web.baseUrl || '').replace(/\/$/, '')
  if (!base.startsWith('https://')) return null
  try {
    const ctrl = new AbortController()
    const timer = setTimeout(() => ctrl.abort(), cfg.web.timeoutMs || 10000)
    const res = await fetch(base + pathname, {
      headers: {
        'X-Bot-Key': key,
        'X-Bot-Level': String(level || 3),
        'X-Bot-Sender': String(sender || '')
      },
      signal: ctrl.signal
    })
    clearTimeout(timer)
    if (!res.ok) return null
    return await res.json()
  } catch (e) { return null }
}
// Bangun prompt hemat: hanya data relevan, bukan seluruh file tiap kali.
function buildContext(question, intent) {
  const cfg = loadConfig()
  const harga = loadCached('harga.json', { items: [] })
  const pengetahuan = loadCached('pengetahuan.json', {})
  const items = harga.items || []
  let hargaText = ''
  if (intent === 'price') {
    const q = normalize(question)
    const hits = items.filter(it => q.includes(normalize(it.nama || it.name || ''))).slice(0, 5)
    hargaText = hits.length
      ? 'Harga cocok: ' + hits.map(it => (it.nama || it.name) + ': ' + (it.harga || it.price) + (it.satuan ? ' / ' + it.satuan : '')).join('; ')
      : 'Daftar nama barang (tanpa harga, hanya nama): ' + items.slice(0, 20).map(it => it.nama || it.name).filter(Boolean).join(', ')
  } else {
    hargaText = 'Nama barang di daftar: ' + items.slice(0, 20).map(it => it.nama || it.name).filter(Boolean).join(', ')
  }
  const tokoText = [pengetahuan.deskripsi, pengetahuan.layanan, pengetahuan.lokasi].filter(Boolean).join('. ').slice(0, 500)
  let prompt = 'Toko: ' + tokoText + '. ' + hargaText + '.'
  if (prompt.length > cfg.context.maxPromptChars) prompt = prompt.slice(0, cfg.context.maxPromptChars) + '...'
  return { prompt, hargaText }
}

// ---------- jawaban ----------
function answerPrice(question) {
  const data = loadCached('harga.json', { items: [] })
  const items = data.items || []
  if (!items.length) {
    return 'Daftar harga belum tersedia. Minta owner kirim daftar harganya dulu, nanti saya jawab dari daftar itu.'
  }
  const q = normalize(question)
  const hit = items.find(it => q.includes(normalize(it.nama || it.name || '')) && (it.nama || it.name))
  if (!hit) {
    const names = items.map(it => it.nama || it.name).filter(Boolean).join(', ')
    return 'Harga yang ditanya belum ada di daftar saya. Yang ada di daftar: ' + names + '.'
  }
  const nama = hit.nama || hit.name
  const harga = hit.harga || hit.price
  const satuan = hit.satuan || hit.unit || ''
  return 'Harga ' + nama + ': ' + harga + (satuan ? ' / ' + satuan : '') + '.'
}

function answerSummary() {
  const orders = loadJson('orders.json', [])
  const today = todayWita()
  const list = orders.filter(o => (o.tanggal || '').startsWith(today))
  if (!list.length) {
    return 'Rangkuman orderan hari ini, ' + today + ': belum ada orderan yang tercatat di grup ini.'
  }
  const lines = list.map((o, i) => (i + 1) + '. ' + (o.isi || o.text || ''))
  return 'Rangkuman orderan hari ini, ' + today + ':\n' + lines.join('\n')
}

function answerHistory() {
  const k = loadCached('pengetahuan.json', {})
  const lines = []
  if (k.deskripsi) lines.push(k.deskripsi)
  if (k.tagline) lines.push('Tagline: "' + k.tagline + '"')
  if (k.lokasi) lines.push('Lokasi: ' + k.lokasi)
  if (k.layanan) lines.push('Layanan: ' + k.layanan)
  if (k.tahun_berdiri || k.pendiri) {
    lines.push('Berdiri: ' + (k.tahun_berdiri || '-') + ', pendiri: ' + (k.pendiri || '-') + '.')
  } else {
    lines.push('Untuk tahun berdiri dan pendiri, saya belum menemukan datanya di chat grup, jadi saya tidak mau mengarang. Owner bisa tambahkan datanya nanti.')
  }
  return lines.join('\n') || 'Saya belum punya data tentang TB Masdar Utama.'
}

async function askMuse2Api(question, remoteJid) {
  if (!MUSE2API_URL || !MUSE2API_KEY) return null
  const cfg = loadConfig()
  const ctx = buildContext(question, 'free')
  const hist = getHistory(remoteJid || '').map(h => 'Q: ' + h.q + ' A: ' + h.a).join('\n').slice(0, 800)
  const prompt =
    'Kamu adalah Madama Agent, asisten di grup WhatsApp toko bahan bangunan TB Masdar Utama. ' +
    'Jawab dalam Bahasa Indonesia sederhana, maksimal 3 kalimat, maksimal ' + cfg.context.maxReplyChars + ' karakter. JANGAN PERNAH sebut nama "Jery". ' +
    'Harga HANYA dari konteks ini, kalau tidak ada katakan belum ada di daftar, jangan karang harga. ' + ctx.prompt + ' ' +
    (hist ? 'Riwayat singkat: ' + hist + ' ' : '') +
    'Pertanyaan: ' + stripTrigger(question)
  try {
    const ctrl = new AbortController()
    const timer = setTimeout(() => ctrl.abort(), 60000)
    const res = await fetch(MUSE2API_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + MUSE2API_KEY },
      body: JSON.stringify({ model: 'muse-chat', messages: [{ role: 'user', content: prompt }] }),
      signal: ctrl.signal
    })
    clearTimeout(timer)
    if (!res.ok) { console.log('muse2api gagal, status:', res.status); return null }
    const data = await res.json()
    const text = data.choices && data.choices[0] && data.choices[0].message && data.choices[0].message.content
    return text ? text.trim() : null
  } catch (e) {
    console.log('muse2api error:', e.message)
    return null
  }
}

async function askGemini(question, remoteJid) {
  if (!GEMINI_API_KEY) return null
  const cfg = loadConfig()
  const ctx = buildContext(question, 'free')
  const hist = getHistory(remoteJid || '').map(h => 'Q: ' + h.q + ' A: ' + h.a).join('\n').slice(0, 800)
  const prompt =
    'Kamu adalah Madama Agent, asisten di grup WhatsApp toko bahan bangunan TB Masdar Utama.\n' +
    'Aturan WAJIB:\n' +
    '- Jawab dalam Bahasa Indonesia sederhana, maksimal 3 kalimat, maksimal ' + cfg.context.maxReplyChars + ' karakter.\n' +
    '- JANGAN PERNAH sebut nama "Jery" di jawaban.\n' +
    '- Harga HANYA dari konteks di bawah. Kalau barang tidak ada di daftar, katakan belum ada di daftar, jangan karang harga.\n' +
    '- Sejarah / pendiri / tahun berdiri HANYA dari konteks. Kalau datanya kosong, katakan terus terang tidak tahu, jangan karang.\n' +
    '- Jangan mengarang nama, barang, jumlah, atau harga orderan.\n' +
    'Konteks toko: ' + ctx.prompt + '\n' +
    (hist ? 'Riwayat singkat: ' + hist + '\n' : '') +
    'Pertanyaan dari grup: ' + stripTrigger(question)
  try {
    const ctrl = new AbortController()
    const timer = setTimeout(() => ctrl.abort(), 15000)
    const res = await fetch(
      'https://generativelanguage.googleapis.com/v1beta/models/' + GEMINI_MODEL + ':generateContent?key=' + GEMINI_API_KEY,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ contents: [{ parts: [{ text: prompt }] }] }),
        signal: ctrl.signal
      }
    )
    clearTimeout(timer)
    if (!res.ok) { console.log('Gemini gagal, status:', res.status); return null }
    const data = await res.json()
    const text = data.candidates && data.candidates[0] && data.candidates[0].content &&
      data.candidates[0].content.parts && data.candidates[0].content.parts[0] &&
      data.candidates[0].content.parts[0].text
    return text ? text.trim() : null
  } catch (e) {
    console.log('Gemini error:', e.message)
    return null
  }
}

async function answer(question, remoteJid, level) {
  const q = normalize(question)
  const isi = stripTrigger(question)
  const lvl = level || 3
  // Perintah tulis (simpan order / buat transaksi / kirim invoice) hanya Level 1-2.
  // Level 3 (baca saja) ditolak sopan, dicatat di audit.
  if (q.includes('simpan') && (q.includes('order') || q.includes('orderan'))) {
    if (lvl === 3) { auditLog({ aksi: 'simpan-order-ditolak', level: lvl }); return 'Maaf, simpan order hanya untuk owner / admin. Kamu bisa tanya harga, stok, atau lihat order.' }
    const orders = loadJson('orders.json', [])
    orders.push({ tanggal: todayWita(), waktu: nowWita(), isi: isi })
    saveJson('orders.json', orders)
    auditLog({ aksi: 'simpan-order', level: lvl })
    return 'Sudah disimpan: ' + isi
  }
  if (q.includes('buatttransaksi') || q.includes('buatkantransaksi') || q.includes('kiriminvoice') || q.includes('kiriminvoicenya') || q.includes('kirimfaktur')) {
    auditLog({ aksi: 'web-tulis-ditolak-belum-aktif', level: lvl })
    return 'Fitur buat transaksi / kirim invoice dari WA belum aktif, masih mode baca file lokal. Owner perlu aktifkan API web dulu, dan perintah tulis harus dikonfirmasi dulu.'
  }
  if (q.includes('rangkum') || q.includes('lihatorder') || q.includes('orderanhariini') || q.includes('daftarorder')) {
    return answerSummary()
  }
  if (q.includes('harga') || q.includes('berapa')) {
    return answerPrice(question)
  }
  if (q.includes('sejarah') || q.includes('tbmasdar') || q.includes('masdarutama')) {
    return answerHistory()
  }
  // Pertanyaan bebas: rate limit dulu, lalu muse2api, lalu Gemini, kalau tidak ada -> catat.
  if (!aiAllowed(remoteJid || 'grup', 'sender')) {
    return 'Tunggu sebentar ya, saya lagi proses pertanyaan sebelumnya.'
  }
  const viaMuse = await askMuse2Api(question, remoteJid)
  if (viaMuse) { addHistory(remoteJid, isi, viaMuse); return viaMuse.slice(0, loadConfig().context.maxReplyChars) }
  const ai = await askGemini(question, remoteJid)
  if (ai) { addHistory(remoteJid, isi, ai); return ai.slice(0, loadConfig().context.maxReplyChars) }
  const un = loadJson('unanswered.json', [])
  un.push({ tanggal: todayWita(), waktu: nowWita(), pertanyaan: isi })
  saveJson('unanswered.json', un)
  return 'Pertanyaan itu saya catat dulu, nanti saya jawab setelah saya cek ke owner.'
}

// ---------- bot ----------
async function start() {
  const { state, saveCreds } = await useMultiFileAuthState('./auth')
  const { version } = await fetchLatestBaileysVersion()
  const sock = makeWASocket({
    version,
    auth: state,
    logger: pino({ level: 'silent' }),
    printQRInTerminal: false,
    browser: ['Ubuntu', 'Chrome', '22.04']
  })
  sock.ev.on('creds.update', saveCreds)

  sock.ev.on('connection.update', async (update) => {
    const { connection, lastDisconnect } = update
    if (connection === 'open') {
      console.log('[' + nowWita() + '] TERHUBUNG sebagai: ' + (sock.user ? sock.user.id : '?'))
      const cfg0 = loadConfig()
      console.log('Madama Agent realtime aktif. Mode: ' + cfg0.mode + '. Grup diizinkan: ' + (cfg0.allowedGroups || []).filter(g => g.enabled !== false).map(g => g.name).join(', ') + '. Hanya balas kalau dipanggil.')
    }
    if (connection === 'close') {
      const code = lastDisconnect && lastDisconnect.error && lastDisconnect.error.output
        ? lastDisconnect.error.output.statusCode : null
      console.log('Koneksi putus, kode:', code)
      if (code === DisconnectReason.loggedOut) {
        console.log('Sesi logout. Hapus folder auth lalu pairing ulang.')
        try { fs.rmSync('./auth', { recursive: true, force: true }) } catch (e) {}
        process.exit(0)
      }
      console.log('Sambung ulang dalam 5 detik...')
      setTimeout(start, 5000)
    }
  })

  if (!state.creds.registered) {
    if (!phone) {
      console.log('Belum terdaftar. Jalankan: node madama-realtime.js --phone 6288804230743')
    } else {
      setTimeout(async () => {
        try {
          const code = await sock.requestPairingCode(phone)
          fs.writeFileSync('pairing-code.txt', code)
          console.log('KODE PAIRING untuk ' + phone + ': ' + code)
          console.log('Masukkan di HP: WhatsApp > Perangkat tertaut > Tautkan perangkat > Tautkan dengan nomor telepon')
        } catch (e) { console.log('Gagal minta pairing code:', e.message) }
      }, 3000)
    }
  }

  sock.ev.on('messages.upsert', async ({ messages }) => {
    for (const m of messages) {
      try {
        if (!m.message || m.key.fromMe) continue
        const remoteJid = m.key.remoteJid || ''
        if (!remoteJid.endsWith('@g.us')) continue // hanya grup
        if (seen.has(m.key.id)) continue
        const text = m.message.conversation
          || m.message.extendedTextMessage?.text
          || m.message.imageMessage?.caption
          || ''
        const botPhone = phone || digitsOnly((sock.user ? sock.user.id : '').split(':')[0].split('@')[0])
        // Ambil info grup dulu (nama, peta LID->HP, LID bot) sebelum cek trigger,
        // karena tag @bot pakai LID bot, dan reply ke bot juga perlu LID bot.
        let subject = getCachedGroup(remoteJid)
        let lidMap = getCachedLidMap(remoteJid)
        let botLid = (groupCache.get(remoteJid) && groupCache.get(remoteJid).botLid) || ''
        if (!subject) {
          try {
            const meta = await sock.groupMetadata(remoteJid)
            subject = meta.subject || ''
            lidMap = lidPhoneMapFromParticipants(meta.participants)
            botLid = botLidFromParticipants(meta.participants, botPhone)
            setCachedGroup(remoteJid, subject, lidMap)
            const e = groupCache.get(remoteJid); if (e) e.botLid = botLid
          } catch (e) { subject = '' }
        }
        // DEBUG sementara: catat SEMUA pesan grup yang masuk, supaya ketahuan
        // apakah pesan sampai ke bot atau tidak, sebelum filter trigger/level.
        console.log('[PESAN MASUK ' + nowWita() + '] grup:' + remoteJid + ' pengirim:' + senderNumber(m) + ' LID:' + senderLid(m) + ' participantAlt:' + (m.key.participantAlt || '-') + ' botLid:' + (botLid || '-') + ' dipanggil:' + isCalled(text, m, botPhone, botLid) + ' teks:' + (text || '').slice(0, 80))
        if (!text || !isCalled(text, m, botPhone, botLid)) continue
        if (!isGroupAllowed(subject, remoteJid)) { console.log('Diabaikan, grup tidak diizinkan:', subject, remoteJid); continue }
        // Semua anggota grup yang diizinkan boleh tanya / chat.
        // Eksekusi tulis (simpan order, buat transaksi, kirim invoice) tetap
        // hanya Level 1 + Level 2 — itu dicek di answer(), bukan di sini.
        // Level dihitung dari nomor HP, LID, atau LID->HP dari info grup,
        // jadi tidak perlu daftarkan LID manual.
        // v2.5: kalau LID ini terpetakan ke nomor Level 1/2 yang sudah
        // terdaftar, LID-nya otomatis ditambah ke roles.json (persist).
        maybeAutoAddLid(m, lidMap)
        const level = senderLevel(m, lidMap)
        console.log('Level pengirim:', level, 'pengirim:', senderNumber(m), 'LID:', senderLid(m), 'HP dari grup:', lidMap[senderLid(m)] || '-')

        markSeen(m.key.id)
        auditLog({ aksi: 'panggil', level, grup: subject, sender: senderNumber(m) })
        const reply = await answer(text, remoteJid, level)
        // JANGAN sebut nama "Jery" — answer() sudah dibuat tanpa nama.
        await sock.sendMessage(remoteJid, { text: reply }, { quoted: m })
        console.log('[' + nowWita() + '] Dibalas di ' + (subject || remoteJid) + ': ' + text.slice(0, 80))
      } catch (e) {
        console.log('Gagal proses pesan:', e.message)
      }
    }
  })
}

start().catch(e => { console.error('Bot error:', e); process.exit(1) })
